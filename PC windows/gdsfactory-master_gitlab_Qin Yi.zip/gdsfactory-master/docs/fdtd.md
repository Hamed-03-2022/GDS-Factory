
```{eval-rst}
.. toctree::
   :maxdepth: 2
   :titlesonly:
   :caption: FDTD:

   notebooks/plugins/lumerical/1_fdtd_sparameters.ipynb
   notebooks/plugins/meep/001_meep_sparameters.ipynb
   notebooks/plugins/meep/002_gratings.ipynb
   notebooks/plugins/tidy3d/00_tidy3d.ipynb
```
