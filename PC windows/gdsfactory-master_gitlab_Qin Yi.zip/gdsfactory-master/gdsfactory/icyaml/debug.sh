#!/bin/bash

export FLASK_ENV=development
flask run
